### Tailwindcss resume template

This is a portfolio designed with Tailwind CSS framework.
If you want to use it, it's free just give an star and that's all you need to do.
